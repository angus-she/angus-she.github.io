<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Document Title -->
    <title>麥永傑會計師事務所 Dennis Mak CPA & CO.</title>

    <!-- Meta -->
    <meta name="description" content="麥永傑會計師事務所提供「一站式」專業會計及財務服務。我們致力為客戶量身定做最佳的業務發展方案，服務範圍涵蓋：成立公司、核數、審計、會計理帳及報稅等。">
    <meta name="keywords" content="麥永傑, 會計師, 會計師樓, 成立公司, 核數, 審計, 會計理帳, 報稅">
    <meta name="author" content="ThemeAtelier">
	<meta name="msvalidate.01" content="278B182E4BBE2000FA9C7901636DD875" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700%7CUbuntu:400,700">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">

    <!-- Bootstrap Framework -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Animate.css Plugin -->
    <link rel="stylesheet" href="css/animate.min.css">

    <!-- Owl Carousel Plugin -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Magnific Popup Plugin -->
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="style.css">

    <!-- Responsive Stylesheet -->
    <link rel="stylesheet" href="css/responsive.css">

    <!-- Theme Color Stylesheet -->
    <link rel="stylesheet" href="css/theme-color.css">

    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- ==== HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries ==== -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-110240920-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'UA-110240920-1');
    </script>

</head>
<body id="body">
    
    <!-- Wrapper Start -->
    <div class="wrapper">
        <!-- Header Section Start -->
        <div class="header--section">
            <!-- Header Topbar Start -->
            <div class="header--topbar bg--color-lightgray">
                <div class="container">
                    <ul class="nav float--left float--xxs-none">
                        <li><a href="tel:85221554190"><i class="fa fa-phone"></i>+852 2155-4190</a></li>
                        <li><a href="tel:85221554193"><i class="fa fa-fax"></i>+852 2155-4193</a></li>
						<li><a href="https://api.whatsapp.com/send?phone=85295351478" target="_blank"><i class="fa fa-whatsapp"></i>+852 9535-1478</a></li>
                        <li><a href="mailto:info@dmcpa.com.hk"><i class="fa fa-envelope-o"></i>info@dmcpa.com.hk</a></li>
                    </ul>

                    <ul class="nav links float--right float--xxs-none">
                        <li><a href="/contact.php?l=tc">繁體</a></li>
                        <li><a href="/contact.php?l=sc">简体</a></li>
                        <li><a href="/contact.php?l=en">ENG</a></li>
                    </ul>
                </div>
            </div>
            <!-- Header Topbar End -->

            <!-- Header Infobar Start -->
            <div class="header--infobar">
                <div class="container">
                    <!-- Logo Start -->
                    <div class="logo float--left">
                    	<h1 class="h1 hidden-md hidden-lg" style="text-align:center">
                        	<a href="/"><img src="img/logo-m.jpg"></a>
                        </h1>
                        <h1 class="h1 hidden-md hidden-lg" style="text-align:center">
                        	<a href="/">麥永傑會計師事務所<br>
                            <div id="en">DENNIS MAK CPA & CO.</div>
							<div id="small">Certified Public Accountant (Practising)</div>
                        </h1>
                        <!--  Hidden in mobile -->
                    	<h1 class="h1 float--left hidden-xs">
                        	<a href="/"><img src="img/logo.jpg"></a>
                        </h1>
                        <h1 class="h1 float--left hidden-xs" style="margin-top: -3px;">
                        	<a href="/">麥永傑會計師事務所<br>
                            <div id="en">DENNIS MAK CPA & CO.</div>
                            <div id="small">Certified Public Accountant (Practising)</div>
                            </a>
                        </h1>
                    </div>
                    <!-- Logo End -->

                    <ul class="info nav float--right hidden-xs">
                        <li>
                            <div class="icon">
                                <i class="fa fa-phone red"></i>
                            </div>
                            <div class="content">
                                <p><strong>Hotlines</strong></p>
                                <p><a href="tel:+85221554190">+852 2155-4190</a></p>
                            </div>
                        </li>
						
                        <li>
                            <div class="icon">
                                <i class="fa fa-whatsapp"></i>
                            </div>
                            <div class="content">
                                <p><strong>WhatsApp</strong></p>
                                <p><a href="https://api.whatsapp.com/send?phone=85295351478" target="_blank">+852 9535-1478</a></p>
                            </div>
                        </li>						
                        
                        <li>
                            <div class="icon">
                                <i class="fa fa-fax"></i>
                            </div>
                            <div class="content">
                                <p><strong>Fax</strong></p>
                                <p><a href="fax:+85221554193">+852 2155-4193</a></p>
                            </div>
                        </li>

                        <li>
                            <div class="icon">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="content">
                                <p>Flat 7, 17/F., Comweb Plaza,<br>No. 12 Cheung Yue Street,<br>Cheung Sha Wan,<br>Kowloon, Hong Kong</p>
                            </div>
                        </li>

                    </ul>
                </div>
            </div>
            <!-- Header Infobar End -->

            <!-- Header Navbar Start -->
            <nav class="header--navbar navbar bg--color-theme" data-sticky="999">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#headerNav" aria-expanded="false">
                            <span class="sr-only">Toggle Navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>

                    <div id="headerNav" class="collapse navbar-collapse">
                        <!-- Header Nav Links Start -->
                        <ul class="header--nav-links nav float--left">
                            <li><a href="/">Home</a></li>
							<li><a href="about.php">About Us</a></li>
							<li><a href="service.php?s=hkcompanysetup">Company Formation</a></li>
							<li><a href="service.php?s=audit">Audit & Assurance</a></li>
							                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Services <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="service.php?s=hkcompanysetup">Hong Kong Company Formation</a></li>
                                    <li><a href="service.php?s=overseascompanysetup">Offshore Company Formation</a></li>
									<li><a href="service.php?s=companysecretary">Company Secretarial Services</a></li>
									<li><a href="service.php?s=addressregistration">Registered Address Services</a></li>
									<li><a href="service.php?s=accounting">Accounting & Bookkeeping</a></li>
                                    <li><a href="service.php?s=taxation">Hong Kong Tax Advisory</a></li>
                                    <li><a href="service.php?s=audit">Audit & Assurance</a></li>
                                    <li><a href="service.php?s=trademarkregistration">Trademark Registration</a></li>
                                    <li><a href="service.php?s=certifiedtruecopy">Certified True Copies (&#34;CTC&#34;)</a></li>                  
                                </ul>
                            </li>
                            <!-- <li><a href="lists.php">Latest News</a></li> -->
							                            <li><a href="contact.php">Contact Us</a></li>
                        </ul>
                        <!-- Header Nav Links End -->
                        <!-- Header Nav Logos Start -->
					    <ul class="header--nav-logos nav float--right">
							<li><img src="img/1.jpg" width="50" /></li>
							<li><img src="img/2.jpg" width="50" /></li>
							<li><img src="img/3.jpg" width="50" /></li>
							<li><img src="img/4.jpg" width="50" /></li>
						</ul>
                   		<!-- Header Nav Logos End -->
                    </div>
                </div>
            </nav>
            <!-- Header Navbar End -->
        </div>
        <!-- Header Section End -->        

        <!-- Contact Section Start -->
        <div class="contact--section pd--40-0 bg--color-lightgray">
            <!-- Contact Map Wrapper Start -->
            <div class="contact--map-wrapper reset--gutter">
                <div class="col-sm-6 col-sm-offset-6">
                    <!-- Contact Map Start -->
                    <div id="map-canvas" class="contact--map"></div>
                    <!-- Contact Map End -->
                </div>
            </div>
            <!-- Contact Map Wrapper End -->

            <!-- Contact Form Start -->
            <div class="contact--form">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="title">
                                <h2 class="h3">Contact Us</h2>
                            </div>
                            
                            <h2 class="h4">Hotlines：</h2>
                            <p><a href="tel:+123456789">Tel： +852 2155-4190</a></p>
                            <p><a href="tel:+123456789">Fax： +852 2155-4193</a></p>
							<p><a href="https://api.whatsapp.com/send?phone=85295351478" target="_blank">WhatsApp： +852 9535-1478</a></p>
							<br>
                            <h2 class="h4">Email：</h2>
                            <p><a href="mailto:info@dmcpa.com.hk">info@dmcpa.com.hk</a></p>
							<br>
                            <h2 class="h4">Office Address：</h2>
                            <p>Flat 7, 17/F., Comweb Plaza,<br>No. 12 Cheung Yue Street,<br>Cheung Sha Wan,<br>Kowloon, Hong Kong</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contact Form End -->
        </div>
        <!-- Contact Section End -->

 


        <!-- Call To Action Start -->
        <div class="call-to-action pd--40-0 bg-red">
            <div class="container">
                <div class="title float--left">
                    <h2 class="h2 mbottom--0">Step ahead towards professional accounting sevices and taxation advices.</h2>
                </div>

                <div class="action float--right">
                    <a href="tel:+85221554190" class="btn btn-default">Call Now +852 2155-4190</a>
                </div>
            </div>
        </div>
        <!-- Call To Action End -->


        

        <!-- Contact Info Section Start -->
        <div class="contact-info--section pd--20-0-20">
            <div class="container">
                <!-- Contact Info Items Start -->
                <div class="contact-info--items">
                    <div class="row">

                        <div class="col-md-3 col-xs-6 col-xxs-12">
                            <!-- Contact Info Item Start -->
                            <div class="contact-info--item">
                                <h2 class="h4">Hotlines：</h2>

                                <p><a href="tel:+85221554190">Tel： +852 2155-4190</a></p>
                                <p><a href="tel:+85221554193">Fax： +852 2155-4193</a></p>
								<p><a href="https://api.whatsapp.com/send?phone=85295351478" target="_blank">WhatsApp： +852 9535-1478</a></p>
                            </div>
                            <!-- Contact Info Item End -->
                        </div>

                        <div class="col-md-3 col-xs-6 col-xxs-12">
                            <!-- Contact Info Item Start -->
                            <div class="contact-info--item">
                                <h2 class="h4">Email：</h2>
                                <p><a href="mailto:info@dmcpa.com.hk">info@dmcpa.com.hk</a></p>
                            </div>
                            <!-- Contact Info Item End -->
                        </div>

                        <div class="col-md-3 col-xs-6 col-xxs-12">
                            <!-- Contact Info Item Start -->
                            <div class="contact-info--item">
                                <h2 class="h4">Office Address：</h2>

                                <p>Flat 7, 17/F., Comweb Plaza,<br>No. 12 Cheung Yue Street,<br>Cheung Sha Wan,<br>Kowloon, Hong Kong</p>
                            </div>
                            <!-- Contact Info Item End -->
                        </div>
                        
                        <div class="col-md-3 col-xs-6 col-xxs-12">
                            <!-- Contact Info Item Start -->
                            <div class="contact-info--item">
                                <h2 class="h4">Qualifications：</h2>

                                <!-- Contact Info Social Start -->
                                <div class="contact-info--social">
                                    <ul class="nav">
                                        <li><img src="img/1.jpg" width="50" /></li>
										<li><img src="img/2.jpg" width="50" /></li>
                                        <li><img src="img/3.jpg" width="50" /></li>
                                        <li><img src="img/4.jpg" width="50" /></li>
                                    </ul>
                                </div>
                                <!-- Contact Info Social End -->
                            </div>
                            <!-- Contact Info Item End -->
                        </div>
                    </div>
                </div>
                <!-- Contact Info Items End -->
            </div>
        </div>
        <!-- Contact Info Section End -->



        <!-- Footer Section Start -->
        <div class="footer--section">
            <!-- Footer Copyright Start -->
            <div class="footer--copyright">
                <div class="container">
				    <p>
						<a href="service.php?s=hkcompanysetup">Hong Kong Company Formation</a> | 
						<a href="service.php?s=overseascompanysetup">Offshore Company Formation</a> | 
						<a href="service.php?s=companysecretary">Company Secretarial Services</a> | 
						<a href="service.php?s=addressregistration">Registered Address Services</a> | 
						<a href="service.php?s=accounting">Accounting & Bookkeeping</a> | 
						<a href="service.php?s=taxation">Hong Kong Tax Advisory</a> | 
						<a href="service.php?s=audit">Audit & Assurance</a> | 
						<a href="service.php?s=trademarkregistration">Trademark Registration</a> | 
						<a href="service.php?s=certifiedtruecopy">Certified True Copies (&#34;CTC&#34;)</a>
					</p>
                	<p><a href="about.php?page=about">About Us</a> | <a href="page.php?page=termsOfUse">Terms of Use</a> | <a href="page.php?page=privacy">Privacy Policy</a> | <a href="page.php?page=disclaimer">Disclaimer</a></p>
                    <p>Copyright 2018 &copy; 麥永傑會計師事務所 Dennis Mak CPA & Co. All Rights Reserved.</p>
                </div>
            </div>
            <!-- Footer Copyright End -->
        </div>
        <!-- Footer Section End -->
    </div>
    <!-- Wrapper End -->

    <!-- Back To Top Button Start -->
    <div id="backToTop" class="bg--color-theme" data-animate-scroll="a">
        <a href="#body"><i class="fa fa-angle-up"></i></a>
    </div>
    <!-- Back To Top Button End -->
	
	
	<!-- Sticky Bottom Bar Start -->
	<div class="fixedfooter hidden-md hidden-lg">
		<div class="col-xs-6 col-xxs-6 whatsapp">
			<a href="https://api.whatsapp.com/send?phone=85295351478" target="_blank"><i class="fa fa-whatsapp"></i> Whatsapp us</a>
		</div>
		<div class="col-xs-6 col-xxs-6 phone">
			<a href="tel:+85221554190"><i class="fa fa-phone"></i> Call us</a>
		</div>
	</div>
	<!-- Sticky Bottom Bar End -->

    <!-- jQuery Library -->
    <script src="js/jquery-3.2.1.min.js"></script>

    <!-- Bootstrap Framework -->
    <script src="js/bootstrap.min.js"></script>

    <!-- StickyJS Plugin -->
    <script src="js/jquery.sticky.min.js"></script>

    <!-- Owl Carousel Plugin -->
    <script src="js/owl.carousel.min.js"></script>

    <!-- Magnific Popup Plugin -->
    <script src="js/jquery.magnific-popup.min.js"></script>

    <!-- Waypoints Plugin -->
    <script src="js/jquery.waypoints.min.js"></script>

    <!-- Counter-Up Plugin -->
    <script src="js/jquery.counterup.min.js"></script>

    <!-- Validation Plugin -->
    <script src="js/jquery.validate.min.js"></script>

    <!-- Isotope Plugin -->
    <script src="js/isotope.min.js"></script>

    <!-- Parallax Plugin -->
    <script src="js/parallax.min.js"></script>

    <!-- AniamteScroll Plugin -->
    <script src="js/animatescroll.min.js"></script>

    <!-- Main Script -->
    <script src="js/main.js"></script>

</body>
</html><script>
  function initMap() {
	var uluru = {lat: 22.3371979, lng: 114.1507520};
	var map = new google.maps.Map(document.getElementById('map-canvas'), {
	  zoom: 18,
	  center: uluru
	});
	var marker = new google.maps.Marker({
	  position: {lat: 22.3374742, lng: 114.1506702},
	  map: map,
	  icon: 'img/flag.png'
	});
	var marker2 = new google.maps.Marker({
	  position: {lat: 22.337225, lng: 114.148693},
	  map: map,
	  icon: 'img/mtr-flag.png'
	});
  }
</script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC3cMQYEKZG1K8zBYSVCGsvBL-ljdci5vo&callback=initMap"></script>